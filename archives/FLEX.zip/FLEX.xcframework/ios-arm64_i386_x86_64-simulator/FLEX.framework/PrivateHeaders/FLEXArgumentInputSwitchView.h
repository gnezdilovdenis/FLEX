//
//  FLEXArgumentInputSwitchView.h
//  Flipboard
//
//  Created by Ryan Olson on 6/16/14.
//  Copyright (c) 2020 FLEX Team. All rights reserved.
//

#import "FLEXArgumentInputView.h"

@interface FLEXArgumentInputSwitchView : FLEXArgumentInputView

@end
